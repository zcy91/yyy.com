<?php
namespace app\index\controller;
use think\AjaxPage;
use think\Controller;
use think\Session;
use think\Url;
use think\Config;
use think\Page;
use think\Verify;
use think\Image;
use think\Db;
use think\Request;
use wxpay;
use alipay;
class Index extends Base 
{
    public function index()
    {
        if(!empty($this->member)){
            $lambnum = db('lamb')->where(array('uid'=>Session::get('user')['user_id'],'status'=>1) )->count();
            $this->assign('lambnum', $lambnum);
            $this->assign('member', $this->member);
        }
        //搜索最近发布的一期羊圈
        $fabu = db('goods')->where(array('shelftime'=>['<=',time()],'stock'=>['>',0],'status'=>1))->order('shelftime','desc')->find();
        $isorder = db('order')
                ->field('o.*,m.username,m.realname,m.mobile')
                ->alias('o')
                ->join('__MEMBER__ m','o.uid=m.id','LEFT')
                ->where(array('o.status'=>1))
                ->group('o.uid')
                ->order('o.creationtime','desc')
                ->limit(10)
                ->select();
        $notice = db('article')->where(array('catid'=>3))->order(array('sort'=>'desc','id'=>'desc','status'=>1))->limit(10)->select();
        $this->assign("notice", $notice);
        $this->assign("fabu", $fabu);
        //$this->assign("isorder", $isorder);
        //获取首页轮播图
        $time = time();
        $ad = db('ad')->where(array('type'=>1,'status'=>1,'stime'=>['<',$time],'etime'=>['>',$time]))->order('id','desc')->select();
        
        $this->assign("ad", $ad);
        
        //获取存栏数和注册人数
        $usernum = db('member')->count();
        $islambnum = db('lamb')->where(array('status'=>['>',0]))->count();
        //今年出栏数
        $yearlambnum = db('lamb')->where(array('status'=>['>',0]))->whereTime('creationtime', 'year')->count();
        //print_r($yearlambnum);
        if(!empty($this->setting['reg_num'])){
            $usernum+=$this->setting['reg_num'];
        }
        if(!empty($this->setting['sold_num'])){
            $islambnum+=$this->setting['sold_num'];
        }
        if(!empty($this->setting['stock_num'])){
            $yearlambnum=$this->setting['stock_num']-$yearlambnum;
        }
        $this->assign('usernum', $usernum);
        $this->assign('islambnum', $islambnum);
        $this->assign('yearlambnum', $yearlambnum);
        $this->assign('webtitle', '我是牧场主');
        return $this->fetch();
    }
    public function mynotify(){
        $notify = new \wxpay\Notify();  
        $data = $notify->Handle();
        file_put_contents('pay_log.txt', $data.PHP_EOL,FILE_APPEND);
    }
    public function alipay(){
        //require dirname ( __FILE__ ).DIRECTORY_SEPARATOR.'./../config.php';
        $config = Db::name('set_alipay')->order('id', 'desc')->find();
       
        if (!empty($_POST['WIDout_trade_no'])&& trim($_POST['WIDout_trade_no'])!=""){
            //商户订单号，商户网站订单系统中唯一订单号，必填
            $out_trade_no = $_POST['WIDout_trade_no'];
            $sntype = substr($out_trade_no, 0, 2);
            if($sntype=='CZ'){
                $result = db('recharge_log')->where(array('rechargesn'=>$out_trade_no,'status'=>'0'))->find();
                //订单名称，必填
                $subject = '支付宝充值余额';

                //付款金额，必填
                $total_amount = $result['money'];

                //商品描述，可空
                $body = '余额充值'.$result['money'].'元';
            }else{
               
                $result = db('order')->where(array('ordersn'=>$out_trade_no,'status'=>'0'))->find();
                //订单名称，必填
                $subject = '支付订单';

                //付款金额，必填
                $total_amount = $result['price'];

                //商品描述，可空
                $body = '支付订单'.$out_trade_no.'';
            }

            

            //超时时间
            $timeout_express="1m";
            $payRequestBuilder = new alipay\wappay\buildermodel\AlipayTradeWapPayContentBuilder();
            $payRequestBuilder->setBody($body);
            $payRequestBuilder->setSubject($subject);
            $payRequestBuilder->setOutTradeNo($out_trade_no);
            $payRequestBuilder->setTotalAmount($total_amount);
            $payRequestBuilder->setTimeExpress($timeout_express);

            $payResponse = new alipay\wappay\service\AlipayTradeService($config);
            $result=$payResponse->wapPay($payRequestBuilder,$config['return_url'],$config['notify_url']);

            return ;
        }
    }
    public function alipay_notify_url(){
        
        $config = Db::name('set_alipay')->order('id', 'desc')->find();


        $arr=$_POST;
        $alipaySevice = new alipay\wappay\service\AlipayTradeService($config); 
        $alipaySevice->writeLog(var_export($_POST,true));
        $result = $alipaySevice->check($arr);
        if($result) {//验证成功
                $out_trade_no = $_POST['out_trade_no'];
                //支付宝交易号
                $trade_no = $_POST['trade_no'];
                //交易状态
                $trade_status = $_POST['trade_status'];
                $out_trade_no = htmlspecialchars($_GET['out_trade_no']);
                //支付宝交易号
                $trade_no = htmlspecialchars($_GET['trade_no']);
                $sntype = substr($out_trade_no, 0, 2);
                if($sntype=='CZ'){
                    $issn = db('recharge_log')->where(array('rechargesn'=>$out_trade_no))->find();
                    $member = db('member')->where('id',$issn['userid'] )->find();
                    $result = db('recharge_log')->where(array('rechargesn'=>$out_trade_no,'status'=>'0'))->update(['status'=>1,'balance'=>($member['credit']+$issn['money'])]);
                    if($result){
                        db('member')->where('id',$member['id'] )->setInc('credit', $issn['money']);
                    }
                    $this->success("充值成功<br />订单号：".$out_trade_no,"/index/index");
                }else{
                    $time=time();
                    $issn = db('order')->where(array('ordersn'=>$out_trade_no))->find();
                    $member = db('member')->where('id',$issn['uid'] )->find();
                    $result = db('order')->where(array('ordersn'=>$out_trade_no,'status'=>'0'))->update(['status'=>1,'paytype'=>3,'paytime'=> $time]);
                    if($result){
                        $data=array(
                            'rechargesn'=>'',
                            'userid'=>$member['id'],
                            'money'=>$issn['money'],
                            'vary'=>2,//1表示增加
                            'balance'=>$member['credit'],//余额
                            'type'=>3,//2表示微信
                            'time'=>$time,
                            'remark'=>'买羊羔',
                            'status'=>1,//生效
                        );
                        db('recharge_log')->insert($data);
                        db('lamb')->where('oid', $issn['id'])->update(['status' => '1','paytime'=>$time]);
                        //处理分销计算
                     //   $commission = $this->setCommission($oid);
                        $this->payhandle($issn['id'], $time);
                    }
                    $this->success("支付成功<br />外部订单号：".$out_trade_no,"/index/index");
                }

            if($_POST['trade_status'] == 'TRADE_FINISHED') {

                        //判断该笔订单是否在商户网站中已经做过处理
                                //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
                                //请务必判断请求时的total_amount与通知时获取的total_fee为一致的
                                //如果有做过处理，不执行商户的业务程序

                        //注意：
                        //退款日期超过可退款期限后（如三个月可退款），支付宝系统发送该交易状态通知
            }
            else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
                        //判断该笔订单是否在商户网站中已经做过处理
                                //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
                                //请务必判断请求时的total_amount与通知时获取的total_fee为一致的
                                //如果有做过处理，不执行商户的业务程序			
                        //注意：
                        //付款完成后，支付宝系统发送该交易状态通知
            }
                //——请根据您的业务逻辑来编写程序（以上代码仅作参考）——

                echo "success";		//请不要修改或删除

        }else {
            //验证失败
            echo "fail";	//请不要修改或删除

        }
    }
    public function alipay_return_url(){
        $config = Db::name('set_alipay')->order('id', 'desc')->find();
        $arr=$_GET;
        $alipaySevice = new alipay\wappay\service\AlipayTradeService($config); 
        $result = $alipaySevice->check($arr);
        if($result) {//验证成功
                $out_trade_no = htmlspecialchars($_GET['out_trade_no']);
                //支付宝交易号
                $trade_no = htmlspecialchars($_GET['trade_no']);
                $sntype = substr($out_trade_no, 0, 2);
                if($sntype=='CZ'){
                    $issn = db('recharge_log')->where(array('rechargesn'=>$out_trade_no))->find();
                    $member = db('member')->where('id',$issn['userid'] )->find();
                    $result = db('recharge_log')->where(array('rechargesn'=>$out_trade_no,'status'=>'0'))->update(['status'=>1,'balance'=>($member['credit']+$issn['money'])]);
                    if($result){
                        db('member')->where('id',$member['id'] )->setInc('credit', $issn['money']);
                    }
                    $this->success("充值成功<br />订单号：".$out_trade_no,"/index/index");
                }else{
                    $time=time();
                    $issn = db('order')->where(array('ordersn'=>$out_trade_no))->find();
                    $member = db('member')->where('id',$issn['uid'] )->find();
                    $result = db('order')->where(array('ordersn'=>$out_trade_no,'status'=>'0'))->update(['status'=>1,'paytype'=>3,'paytime'=> $time]);
                    if($result){
                        $data=array(
                            'rechargesn'=>'',
                            'userid'=>$member['id'],
                            'money'=>$issn['money'],
                            'vary'=>2,//1表示增加
                            'balance'=>$member['credit'],//余额
                            'type'=>3,//2表示微信
                            'time'=>$time,
                            'remark'=>'买羊羔',
                            'status'=>1,//生效
                        );
                        db('recharge_log')->insert($data);
                        db('lamb')->where('oid', $issn['id'])->update(['status' => '1','paytime'=>$time]);
                        //处理分销计算
                      //  $commission = $this->setCommission($oid);
                        $this->payhandle($issn['id'], $time);
                    }
                    $this->success("支付成功<br />外部订单号：".$out_trade_no,"/index/index");
                }
                //——请根据您的业务逻辑来编写程序（以上代码仅作参考）——

                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        }
        else {
            //验证失败
            $this->success("验证失败","/index/index");
        }
    }

    public function notice_detail(){
        $id= input('id');
        $myarticle = db('article')->where(array('id'=>$id,'status'=>1))->find();
        $userId = $myarticle['userid'];
        $list = db('comment') -> where(array('aid'=>$id,'status'=>1))-> select();
        if(!empty($myarticle)){
            $myarticle['img'] = unserialize($myarticle['img']); // 晒单图片
            $this->assign('myarticle', $myarticle);
        }else{
            exit();
        }
        if(!empty(Session::get('user.user_id'))){
            $userid = Session::get('user.user_id');
            if($userid == $userId){
                $isdelarticle = 1;
            }
            $iszan = db('comment') -> where('userid',$userid)->where('aid',$id)->where("comment is null")->value('iszan');
        }elseif(@$_COOKIE['mobile']){
            $mobile = $_COOKIE['mobile'];
            $userid = db('member') -> where('mobile',$mobile) -> value('id');
            if($userid == $userId){
                $isdelarticle = 1;
            }
            $iszan = db('comment') -> where('userid',$userid)->where('aid',$id)->where("comment is null")->value('iszan');
        }else{
            $iszan = 0;
        }
        db('article') -> where('id',$id)->setInc('hits'); //增加阅读
        $this -> assign('iszan',$iszan);
        $this->assign('webtitle', '公告');
        return $this->fetch();
    }

    public function notice_list(){
        $notice_list = db('article')->where(array('catid'=>3))->order(array('sort'=>'desc','id'=>'desc','status'=>1))->select();
        $count = count($notice_list);
        $page_count = 15;
        $page = new AjaxPage($count, $page_count);
        $list = db('article')->where(array('catid'=>3,'status'=>1))->order(array('sort'=>'desc','id'=>'desc'))->limit($page->firstRow . ',' . $page->listRows) ->select();
        foreach ($list as $s=>$v){
            $list[$s]['timestr'] = time_tran($v['createtime']);
            $list[$s]['content'] = strip_tags($v['content']);
            $list[$s]['content'] = filterComment($list[$s]['content']);
            $list[$s]['img'] = unserialize($v['img']); // 晒单图片
        }
        if(empty(input('get.p'))){
            $p = 0;
        }else{
            $p = input('get.p');
        }
        $this->assign('list', $list);
        $this->assign('commentlist', $list);
        $this->assign('count', $count);//总条数
        $this->assign('page_count', $page_count);//页数
        $this->assign('current_count', $page_count * input('get.p'));//当前条
        $this->assign('p', $p);//页数
        return $this->fetch();
    }

    public function ajaxnotice(){
        $count = count(db('article')->where(array('catid'=>3,'status'=>1))->order(array('sort'=>'desc','id'=>'desc'))->select());
        $page_count = 15;
        $page = new AjaxPage($count, $page_count);
        $list = db('article')->where(array('catid'=>3,'status'=>1))->order(array('sort'=>'desc','id'=>'desc'))->limit($page->firstRow . ',' . $page->listRows) ->select();
        foreach ($list as $s=>$v){
            $list[$s]['timestr'] = time_tran($v['createtime']);
            $list[$s]['content'] = strip_tags($v['content']);
            $list[$s]['content'] = filterComment($list[$s]['content']);
            $list[$s]['img'] = unserialize($v['img']); // 晒单图片
        }
        if(empty(input('get.p'))){
            $p = 0;
        }else{
            $p = input('get.p');
        }
        $this->assign('list', $list);
        $this->assign('commentlist', $list);
        $this->assign('count', $count);//总条数
        $this->assign('page_count', $page_count);//页数
        $this->assign('current_count', $page_count * input('get.p'));//当前条
        $this->assign('p', $p);//页数
        return $this->fetch();
    }

    
}
