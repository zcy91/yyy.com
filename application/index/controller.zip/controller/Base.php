<?php

namespace app\index\controller;
use think\Controller;
use think\Db;
use think\Session;
use think\Input;
use clt\Leftnav;
use think\Request;
use PHPMailer\PHPMailer;

use mywechat;
use alidayu;

class Base extends Controller  {
    public $member;
    public $setting;
    public $wc;
    function _initialize()
    {
        $data = db('sell_lamb')->where(['exchange'=>3,'status'=>2,'issend'=>0])->where("stime <= ".time())->limit(5)->select();
        foreach ($data as $v){
            $oid = db('lamb')->where('id',$v['lambid'])->value('oid');
            $this->setCommissionOne($oid,$v['lambid']);
        }

//       var_dump($data);die;
        $request = Request::instance();
        $action = $request->action();
        $controller = $request->controller();
        $this->assign('controller', strtolower($controller));
        define('MODULE_NAME', strtolower($controller));
        if (MODULE_NAME == 'user' || MODULE_NAME == 'order'|| MODULE_NAME == 'mall'|| MODULE_NAME == 'shop') {
            if (!Session::has('user')) {
//            if (strstr($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')) {  //判断微信浏览器
//                $this->wc = Db::name('wx_set')->find();
//
//                if (empty($_GET['code'])) {
//                    $appid = $this->wc['appid'];
//                    $redirect_uri = urlencode($this->get_url());
//                    $wxchat = new mywechat\wechat();
//                    $wxchat->getCode1($appid, $redirect_uri, $wx = 'wx');
//                    exit();
//                } else {
//                    $code = $_GET['code'];
//                    $appid = $this->wc['appid'];
//                    $appsecret = $this->wc['appsecret'];
//                    $wxchat_token = new mywechat\wechat();
//                    $access_token = $wxchat_token->getWebAccessToken1($appid, $appsecret, $code);
//                    //dump($access_token);die;
//                    if (empty($access_token['openid'])) {
//                        $this->success("Openid获取失败！", url("/index/index/index"));
//                    }
//                    $accesstoken = mywechat\wechat::getAccessToken($appid, $appsecret);
//                    $user_info = mywechat\wechat::getUserInfo($accesstoken, $access_token['openid'], 2);
//                }
//                if (!empty($user_info['subscribe']) && $user_info['subscribe'] == 1) {
//                    $status = Db::name('member')->where('openid', $user_info['openid'])->where('unionid', $user_info['unionid'])->find();
//                    if (!empty($status)) {
//                        Session::set('user', array("user_id" => $status['id'], 'openid' => $status['openid'], 'unionid' => $status['unionid']));
//                        $this->member = db('member')->where('id', Session::get('user')['user_id'])->find();
//                        $agentid = $this->member['id'];
//                    }
//
//                }
//            }
                if(!empty($_COOKIE['app_token'])){
                $userarr = db('member') -> where('unionid',$_COOKIE['app_token'])->find();
                    if(!empty($userarr)){
                        Session::set('user', array("user_id" => $userarr['id'], 'openid' => $userarr['openid'], 'unionid' => $userarr['unionid']));
                    }
                }
                else if (empty($_COOKIE['mobile']) || empty($_COOKIE['password'])) {
                    header("Location: " . url('/index/login/login'));
                    exit();
                } else {
                    $password = $_COOKIE['password'];
                    $mobile = $_COOKIE['mobile'];
                    $where = ['mobile' => $mobile, 'status' => 0];
                    $pass = db('member')->where($where)->value('password');
                    $pass = md5('yyy') . $pass . 'yyy';
                    if ($password == $pass) {
                        $status = db('member')->where($where)->find();
                        Session::set('user', array("user_id" => $status['id'], 'openid' => $status['openid'], 'unionid' => $status['unionid']));
                        $this->member = db('member')->where('id', Session::get('user')['user_id'])->find();
                        $agentid = $this->member['id'];
                    } else {
                        header("Location: " . url('/index/login/login'));
                        exit();
                    }

                }
            }

            if (Session::has('user')) {
                $this->member = db('member')->where('id', Session::get('user')['user_id'])->find();
                $agentid = $this->member['id'];
            }
        }
            $this->setting = Db::name('setting')->find();
            $this->wc = Db::name('wx_set')->find();
            $wxset = Db::name('wx_set')->find();
            $jssdk = new mywechat\jssdk($wxset['appid'], $wxset['appsecret']);//()($wxset['appid'], $wxset['appsecret'])
            try {
                $signPackage = $jssdk->GetSignPackage();
            } catch (\Exception $e) {
                $signPackage = array();
            }
            //获取客户端
            $clientType = fangwenleixing();
            $this->assign('clientType', $clientType);
            $this->assign('signPackage', $signPackage);
            $this->assign('setting', $this->setting);

    }

    /**
     * 获取当前的url 地址
     * @return type
     */
    private function get_url() {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }

    function sendmail($title,$content,$address=''){
        $emailset = Db::name('email_set')->order('id', 'desc')->find();
         //实例化
        $mail=new PHPMailer\PHPMailer;
        try{
            //邮件调试模式
            $mail->SMTPDebug = 0;  
            //设置邮件使用SMTP
            $mail->isSMTP();
            // 设置邮件程序以使用SMTP
            $mail->Host = $emailset['host'];
            // 设置邮件内容的编码
            $mail->CharSet='UTF-8';
            // 设置中文提示
            // 
            // 启用SMTP验证
            $mail->SMTPAuth = true;
            // SMTP username
            $mail->Username = $emailset['username'];
            // SMTP password
            $mail->Password = $emailset['password'];
            // 启用TLS加密，`ssl`也被接受
            if(!empty($emailset['secure'])){
                $mail->SMTPSecure = 'tls';
            }
            // 连接的TCP端口
            $mail->Port = $emailset['port'];
            //设置发件人
            $mail->setFrom($emailset['from']);
           //  添加收件人
            if(empty($address)){
                $mail->addAddress($emailset['address']);
            } else {
                $mail->addAddress($address);
            }
            

            $mail->isHTML(true);
            $mail->Subject = $title;
            $mail->Body    = $content;
//            $mail->AltBody = '这是非HTML邮件客户端的纯文本';
            $issend = $mail->send();
            
            $mail->isSMTP();
            if($issend){
                return array('status'=>1,'msg'=>'发送成功！');
            }else{
                return array('status'=>0,'msg'=>$mail->ErrorInfo);
            }
        }catch (Exception $e){
            return array('status'=>0,'msg'=>$mail->ErrorInfo);
        }
    }
    
    function payhandle($oid,$time,$issms=true){
        $mygoods = Db::name('order_goods')
                    ->field('g.*,o.ordersn')
                    ->alias('og')
                    ->join('__GOODS__ g','og.gid = g.id','LEFT')
                    ->join('__ORDER__ o','og.oid = o.id','LEFT')
                    ->where(array('og.oid'=>$oid))
                    ->select();
        if($issms){
            //短信提示购买成功
            //SMS_122282350:尊敬的${name}，恭喜您认领${goods}成功，成为食花百草羊尊贵牧场主！
            $smsset=Db::name('sms_set')->find();
            $phone = $this->member['mobile'];
            $smsname = $this->member['username'];
            $smsgoods = $mygoods[0]['gname'];
            $smsorder = $mygoods[0]['ordersn'];
            if($smsset['status']==1 && !empty($phone)){//开启了短信接口
                $sms = new \alidayu\SmsApi($smsset['access_key_id'], $smsset['access_key_secret']);
                $response = $sms->sendSms(
                    $smsset['sms_autograph'], // 短信签名
                    'SMS_122282350', // 短信模板编号
                    "$phone", // 短信接收者
                    Array (  // 短信模板中字段的值
                        "name"=>"$smsname",
                        "goods"=>"$smsgoods",
                        "order"=>"$oid"
                    ),
                    "123"   // 流水号,选填
                );
                if($response['Code']=='OK'){
                    //print_r( array('type'=>1,'data'=>'验证码发送成功！'));
                }else{
                    //print_r( array('type'=>2,'data'=>'发送失败，错误代码：'.$response['Code']));
                }
            }
        }
        
        
        //如果该商品有积分的话送积分。
        
        $integral=0;
        foreach ($mygoods as $v){
            if(!empty($v['integral'])){
                if($v['integral']>0){
                    Db::name('member')->where('id', $this->member['id'])->setInc('credit2', $v['integral']);
                    //积分做记录
                    $iscredit2 = Db::name('member')->where('id', $this->member['id'])->find();
                    $recharge_data=array(
                        'userid'=>$this->member['id'],
                        'money_type'=>2,
                        'money'=>$v['integral'],
                        'vary'=>1,
                        'type'=>1,
                        'time'=>time(),
                        'remark'=>'购买送积分',
                        'balance'=>$iscredit2['credit2']+$v['integral'],
                        'status'=>'1',
                    );
                    $isrecharge=db('recharge_log')->insert($recharge_data);
                }
                
            }
            $integral+=$v['integral'];
            //生成涨幅
            if(!empty($v['percentage'])){
                $total = round($v['price'] * $v['percentage']/100, 2);
                $num = 365 ; 
                if($total>=10){
                    $hongbaoarr = hongbao($total, $num);
                    $mylamb = Db::name('lamb')->where(array('oid'=>$oid,'status'=>1))->select();
                    //获取零点时间戳
                    $lingtime = strtotime(date("Y-m-d ", $time));
                    foreach ($mylamb as $v){
                        //存序列化中。
                        $rose = array();
                        foreach ($hongbaoarr as $ss=>$vv){
                             $rose[$lingtime+($ss*86400)]=$vv;
                        }
                        $serrose = serialize($rose);
                        Db::name('lamb')->where('id', $v['id'])->update(['rose' => $serrose]);
                    }
                }
            }
        }
        if(!empty($integral)){
            return $integral;
        }else{
            return 0;
        }
    }
    /**
     * 
     * @param type $uid 设置推荐奖励
     */
    public function setRecommend($uid){
        if(!empty($uid)){
            $member = db('member')->where(array('id'=>$uid))->find();
            if(!empty($member)){
                $agentid = $member['agentid'];
            }
            if(!empty($agentid)){
                $agentmember = db('member')
                                ->field('m.id,m.credit,m.credit2,ml.isrecommend,ml.recommend_type,ml.recommend_prize')
                                ->alias('m')
                                ->join('__MEMBER_LEVEL__ ml','m.level = ml.level','LEFT')
                                ->where(array('m.id'=>$agentid))
                                ->find();
                        //print_r($agentmember);
                if(!empty($agentmember['isrecommend'])){
                    if($agentmember['recommend_type']==1){
                        $data = array(
                            'ordersn'=>0,
                            'og_id'=>0,
                            'prizeid'=>$agentid,
                            'money_type'=>1,
                            'money'=>$agentmember['recommend_prize'],
                            'type'=>4,
                            'content'=>'邀请好友送'.$agentmember['recommend_prize'].'余额',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$agentmember['id'] )->setInc('credit', $agentmember['recommend_prize']);
                        $recharge_data=array(
                            'userid'=>$agentmember['id'],
                            'money'=>$agentmember['recommend_prize'],
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'邀请送',
                            'balance'=>$agentmember['credit']+$agentmember['recommend_prize'],
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }elseif($agentmember['recommend_type']==2){
                        $data = array(
                            'ordersn'=>0,
                            'og_id'=>0,
                            'prizeid'=>$agentid,
                            'money_type'=>2,
                            'money'=>$agentmember['recommend_prize'],
                            'type'=>4,
                            'content'=>'邀请好友送'.$agentmember['recommend_prize'].'积分',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$agentmember['id'] )->setInc('credit2', $agentmember['recommend_prize']);
                        $recharge_data=array(
                            'userid'=>$agentmember['id'],
                            'money_type'=>2,
                            'money'=>$agentmember['recommend_prize'],
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'邀请送',
                            'balance'=>$agentmember['credit2']+$agentmember['recommend_prize'],
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }elseif($agentmember['recommend_type']==3) {
                        $data = array(
                            'uid'=>$agentid,
                            'couponid'=>$agentmember['recommend_prize'],
                            'gettype'=>3,
                            'gettime'=> time(),
                        );
                        db('coupon_data')->insert($data);
                    }
                }
            }
        }
    }
    
    /**
     * 
     * @param type $uid 设置分销奖励
     */
    public function setCommission($oid){
        //获取订单信息
        $isorder = db('order')->where(array('id'=>$oid,'status'=>['>=',1],'status'=>['<',4]))->find();
        if(!empty($isorder['uid'])){
            //获取买家信息
            $buy = db('member')->where(array('id'=>$isorder['uid']))->find();
            //获取买家上级
            if(!empty($buy['agentid'])){
                $onemember = db('member')->where(array('id'=>$buy['agentid']))->find();
                //获取一级上级的权限
                $onelelver = db('member_level')->where(array('level'=>$onemember['level']))->find();
                if(!empty($onemember['agentid'])){
                    $twomember = db('member')->where(array('id'=>$onemember['agentid']))->find();
                    //获取一级上级的权限
                    $twolelver = db('member_level')->where(array('level'=>$twomember['level']))->find();
                    if(!empty($twomember['agentid'])){
                        $threemember = db('member')->where(array('id'=>$twomember['agentid']))->find();
                        //获取一级上级的权限
                        $threelelver = db('member_level')->where(array('level'=>$threemember['level']))->find();
                    }
                }
            }
            //获取订单对应的商品订单表
            $order_goods = db('order_goods')->where(array('oid'=>$oid))->select();
            foreach ($order_goods as $v){
                //1级
                if(!empty($onelelver['iscommission'])){
                    $onemoney = 0;
                    if($onelelver['commission_way']==1){
                        $onemoney = $onelelver['commission1'] *$v['num'];
                    }else{
                        $onemoney = $onelelver['commission1']*$v['money']/100;
                    }
                    if($onelelver['commission_type']==1 && $onemoney>0){
                        $data = array(
                            'ordersn'=>$isorder['ordersn'],
                            'og_id'=>$v['id'],
                            'prizeid'=>$onemember['id'],
                            'money_type'=>1,
                            'money'=>$onemoney,
                            'type'=>1,
                            'content'=>'一级分销奖送'.$onemoney.'余额',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$onemember['id'] )->setInc('credit', $onemoney);
                        $recharge_data=array(
                            'userid'=>$onemember['id'],
                            'money'=>$onemoney,
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'一级分销送',
                            'balance'=>$onemember['credit']+$onemoney,
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }elseif($onelelver['commission_type']==2 && $onemoney>0){
                        $data = array(
                            'ordersn'=>$isorder['ordersn'],
                            'og_id'=>$v['id'],
                            'prizeid'=>$onemember['id'],
                            'money_type'=>2,
                            'money'=>$onemoney,
                            'type'=>1,
                            'content'=>'一级分销奖送'.$onemoney.'积分',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$onemember['id'] )->setInc('credit2', $onemoney);
                        $recharge_data=array(
                            'userid'=>$onemember['id'],
                            'money_type'=>2,
                            'money'=>$onemoney,
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'一级分销送',
                            'balance'=>$onemember['credit2']+$onemoney,
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }
                }
                //2级
                if(!empty($twolelver['iscommission'])){
                    $twomoney = 0;
                    if($twolelver['commission_way']==1){
                        $twomoney = $twolelver['commission2'];
                    }else{
                        $twomoney = $twolelver['commission2']*$v['money']/100;
                    }
                    if($twolelver['commission_type']==1 && $twomoney>0){
                        $data = array(
                            'ordersn'=>$isorder['ordersn'],
                            'og_id'=>$v['id'],
                            'prizeid'=>$twomember['id'],
                            'money_type'=>1,
                            'money'=>$twomoney,
                            'type'=>2,
                            'content'=>'二级分销奖送'.$twomoney.'余额',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$twomember['id'] )->setInc('credit', $twomoney);
                        $recharge_data=array(
                            'userid'=>$twomember['id'],
                            'money'=>$twomoney,
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'二级分销送',
                            'balance'=>$twomember['credit']+$twomoney,
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }elseif($twolelver['commission_type']==2 && $twomoney>0){
                        $data = array(
                            'ordersn'=>$isorder['ordersn'],
                            'og_id'=>$v['id'],
                            'prizeid'=>$twomember['id'],
                            'money_type'=>2,
                            'money'=>$twomoney,
                            'type'=>2,
                            'content'=>'二级分销奖送'.$twomoney.'积分',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$twomember['id'] )->setInc('credit2', $twomoney);
                        $recharge_data=array(
                            'userid'=>$twomember['id'],
                            'money_type'=>2,
                            'money'=>$twomoney,
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'二级分销送',
                            'balance'=>$twomember['credit2']+$twomoney,
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }
                }//3级
                if(!empty($threelelver['iscommission'])){
                    $threemoney = 0;
                    if($threelelver['commission_way']==1){
                        $threemoney = $threelelver['commission3'];
                    }else{
                        $threemoney = $threelelver['commission3']*$v['money']/100;
                    }
                    if($threelelver['commission_type']==1 && $threemoney>0){
                        $data = array(
                            'ordersn'=>$isorder['ordersn'],
                            'og_id'=>$v['id'],
                            'prizeid'=>$threemember['id'],
                            'money_type'=>1,
                            'money'=>$threemoney,
                            'type'=>3,
                            'content'=>'三级分销奖送'.$threemoney.'余额',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$threemember['id'] )->setInc('credit', $threemoney);
                        $recharge_data=array(
                            'userid'=>$threemember['id'],
                            'money'=>$threemoney,
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'三级分销送',
                            'balance'=>$threemember['credit']+$threemoney,
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }elseif($threelelver['commission_type']==2 && $threemoney>0){
                        $data = array(
                            'ordersn'=>$isorder['ordersn'],
                            'og_id'=>$v['id'],
                            'prizeid'=>$threemember['id'],
                            'money_type'=>2,
                            'money'=>$threemoney,
                            'type'=>3,
                            'content'=>'三级分销奖送'.$threemoney.'积分',
                            'stime'=>time(),
                            'etime'=>time(),
                            'statue'=>3,
                        );
                        db('commission_log')->insert($data);
                        db('member')->where('id',$threemember['id'] )->setInc('credit2', $threemoney);
                        $recharge_data=array(
                            'userid'=>$threemember['id'],
                            'money_type'=>2,
                            'money'=>$threemoney,
                            'vary'=>1,
                            'type'=>1,
                            'time'=>time(),
                            'remark'=>'三级分销送',
                            'balance'=>$threemember['credit2']+$threemoney,
                            'status'=>'1',
                        );
                        $isrecharge=db('recharge_log')->insert($recharge_data);
                    }
                }

                
            }
            
            
        }
    }

    public function setCommissionOne($oid,$lambid){
        //获取订单信息
        $isorder = db('order')->where(array('id'=>$oid,'status'=>['>=',1],'status'=>['<',4]))->find();
        if(!empty($isorder['uid'])){
            //获取买家信息
            $buy = db('member')->where(array('id'=>$isorder['uid']))->find();
            //获取买家上级
            if(!empty($buy['agentid'])){
                $onemember = db('member')->where(array('id'=>$buy['agentid']))->find();
                //获取一级上级的权限
                $onelelver = db('member_level')->where(array('level'=>$onemember['level']))->find();
                if(!empty($onemember['agentid'])){
                    $twomember = db('member')->where(array('id'=>$onemember['agentid']))->find();
                    //获取一级上级的权限
                    $twolelver = db('member_level')->where(array('level'=>$twomember['level']))->find();
                    if(!empty($twomember['agentid'])){
                        $threemember = db('member')->where(array('id'=>$twomember['agentid']))->find();
                        //获取一级上级的权限
                        $threelelver = db('member_level')->where(array('level'=>$threemember['level']))->find();
                    }
                }
            }
            //获取订单对应的商品订单表
            $order_goods = db('order_goods')->where(array('oid'=>$oid))->select();
            $count = db('commission_log')->where('ordersn',$isorder['ordersn'])->count();
            if($order_goods[0]['num']<=$count){
                return false;
            }
            $res = db('commission_log')->where(array('statue'=>3,'lambid'=>$lambid))->find();
            if($res){
                return false;
            }
            $result = db('sell_lamb')->where('lambid',$lambid)->where('status',2)->where('exchange',1)->update(array('issend'=>1));
            $res = db('sell_lamb')->where('lambid',$lambid)->where('status',2)->where('exchange',3)->update(array('issend'=>1));
            if($res || $result){
                foreach ($order_goods as $v){
                    //1级
                    if(!empty($onelelver['iscommission'])){
                        $onemoney = 0;
                        if($onelelver['commission_way']==1){
                            $onemoney = $onelelver['commission1'] ;
                        }else{
                            $onemoney = $onelelver['commission1']*$v['money']/100;
                        }
                        if($onelelver['commission_type']==1 && $onemoney>0){
                            $data = array(
                                'ordersn'=>$isorder['ordersn'],
                                'og_id'=>$v['id'],
                                'prizeid'=>$onemember['id'],
                                'money_type'=>1,
                                'money'=>$onemoney,
                                'type'=>1,
                                'content'=>'一级分销奖送'.$onemoney.'余额',
                                'stime'=>time(),
                                'etime'=>time(),
                                'statue'=>3,
                                'lambid'=>$lambid
                            );
                            db('commission_log')->insert($data);
                            db('member')->where('id',$onemember['id'] )->setInc('credit', $onemoney);
                            $recharge_data=array(
                                'userid'=>$onemember['id'],
                                'money'=>$onemoney,
                                'vary'=>1,
                                'type'=>1,
                                'time'=>time(),
                                'remark'=>'一级分销送',
                                'balance'=>$onemember['credit']+$onemoney,
                                'status'=>'1',
                                'lambid'=>$lambid
                            );
                            $isrecharge=db('recharge_log')->insert($recharge_data);
                        }elseif($onelelver['commission_type']==2 && $onemoney>0){
                            $data = array(
                                'ordersn'=>$isorder['ordersn'],
                                'og_id'=>$v['id'],
                                'prizeid'=>$onemember['id'],
                                'money_type'=>2,
                                'money'=>$onemoney,
                                'type'=>1,
                                'content'=>'一级分销奖送'.$onemoney.'积分',
                                'stime'=>time(),
                                'etime'=>time(),
                                'statue'=>3,
                                'lambid'=>$lambid
                            );
                            db('commission_log')->insert($data);
                            db('member')->where('id',$onemember['id'] )->setInc('credit2', $onemoney);
                            $recharge_data=array(
                                'userid'=>$onemember['id'],
                                'money_type'=>2,
                                'money'=>$onemoney,
                                'vary'=>1,
                                'type'=>1,
                                'time'=>time(),
                                'remark'=>'一级分销送',
                                'balance'=>$onemember['credit2']+$onemoney,
                                'status'=>'1',
                                'lambid'=>$lambid
                            );
                            $isrecharge=db('recharge_log')->insert($recharge_data);
                        }
                    }
                    //2级
                    if(!empty($twolelver['iscommission'])){
                        $twomoney = 0;
                        if($twolelver['commission_way']==1){
                            $twomoney = $twolelver['commission2'];
                        }else{
                            $twomoney = $twolelver['commission2']*$v['money']/100;
                        }
                        if($twolelver['commission_type']==1 && $twomoney>0){
                            $data = array(
                                'ordersn'=>$isorder['ordersn'],
                                'og_id'=>$v['id'],
                                'prizeid'=>$twomember['id'],
                                'money_type'=>1,
                                'money'=>$twomoney,
                                'type'=>2,
                                'content'=>'二级分销奖送'.$twomoney.'余额',
                                'stime'=>time(),
                                'etime'=>time(),
                                'statue'=>3,
                                'lambid'=>$lambid
                            );
                            db('commission_log')->insert($data);
                            db('member')->where('id',$twomember['id'] )->setInc('credit', $twomoney);
                            $recharge_data=array(
                                'userid'=>$twomember['id'],
                                'money'=>$twomoney,
                                'vary'=>1,
                                'type'=>1,
                                'time'=>time(),
                                'remark'=>'二级分销送',
                                'balance'=>$twomember['credit']+$twomoney,
                                'status'=>'1',
                                'lambid'=>$lambid
                            );
                            $isrecharge=db('recharge_log')->insert($recharge_data);
                        }elseif($twolelver['commission_type']==2 && $twomoney>0){
                            $data = array(
                                'ordersn'=>$isorder['ordersn'],
                                'og_id'=>$v['id'],
                                'prizeid'=>$twomember['id'],
                                'money_type'=>2,
                                'money'=>$twomoney,
                                'type'=>2,
                                'content'=>'二级分销奖送'.$twomoney.'积分',
                                'stime'=>time(),
                                'etime'=>time(),
                                'statue'=>3,
                                'lambid'=>$lambid
                            );
                            db('commission_log')->insert($data);
                            db('member')->where('id',$twomember['id'] )->setInc('credit2', $twomoney);
                            $recharge_data=array(
                                'userid'=>$twomember['id'],
                                'money_type'=>2,
                                'money'=>$twomoney,
                                'vary'=>1,
                                'type'=>1,
                                'time'=>time(),
                                'remark'=>'二级分销送',
                                'balance'=>$twomember['credit2']+$twomoney,
                                'status'=>'1',
                                'lambid'=>$lambid
                            );
                            $isrecharge=db('recharge_log')->insert($recharge_data);
                        }
                    }//3级
                    if(!empty($threelelver['iscommission'])){
                        $threemoney = 0;
                        if($threelelver['commission_way']==1){
                            $threemoney = $threelelver['commission3'];
                        }else{
                            $threemoney = $threelelver['commission3']*$v['money']/100;
                        }
                        if($threelelver['commission_type']==1 && $threemoney>0){
                            $data = array(
                                'ordersn'=>$isorder['ordersn'],
                                'og_id'=>$v['id'],
                                'prizeid'=>$threemember['id'],
                                'money_type'=>1,
                                'money'=>$threemoney,
                                'type'=>3,
                                'content'=>'三级分销奖送'.$threemoney.'余额',
                                'stime'=>time(),
                                'etime'=>time(),
                                'statue'=>3,
                                'lambid'=>$lambid
                            );
                            db('commission_log')->insert($data);
                            db('member')->where('id',$threemember['id'] )->setInc('credit', $threemoney);
                            $recharge_data=array(
                                'userid'=>$threemember['id'],
                                'money'=>$threemoney,
                                'vary'=>1,
                                'type'=>1,
                                'time'=>time(),
                                'remark'=>'三级分销送',
                                'balance'=>$threemember['credit']+$threemoney,
                                'status'=>'1',
                                'lambid'=>$lambid
                            );
                            $isrecharge=db('recharge_log')->insert($recharge_data);
                        }elseif($threelelver['commission_type']==2 && $threemoney>0){
                            $data = array(
                                'ordersn'=>$isorder['ordersn'],
                                'og_id'=>$v['id'],
                                'prizeid'=>$threemember['id'],
                                'money_type'=>2,
                                'money'=>$threemoney,
                                'type'=>3,
                                'content'=>'三级分销奖送'.$threemoney.'积分',
                                'stime'=>time(),
                                'etime'=>time(),
                                'statue'=>3,
                                'lambid'=>$lambid
                            );
                            db('commission_log')->insert($data);
                            db('member')->where('id',$threemember['id'] )->setInc('credit2', $threemoney);
                            $recharge_data=array(
                                'userid'=>$threemember['id'],
                                'money_type'=>2,
                                'money'=>$threemoney,
                                'vary'=>1,
                                'type'=>1,
                                'time'=>time(),
                                'remark'=>'三级分销送',
                                'balance'=>$threemember['credit2']+$threemoney,
                                'status'=>'1',
                                'lambid'=>$lambid
                            );
                            $isrecharge=db('recharge_log')->insert($recharge_data);
                        }
                    }
                    db('sell_lamb')->where('lambid',$lambid)->update(array('issend'=>1));
                }
            }
        }
    }
    
    public function fengpei($ordersn,$ogid,$prize){
        
    }
}